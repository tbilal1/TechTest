﻿using CsvHelper.Configuration.Attributes;
using System.Collections.Generic;

namespace DevTest.Apps.ProductSales.Common.Models
{
    public class Product
    {
        //public int? Id { get; set; }

        [Name("Product")]
        public required string Name { get; set; }

        [Name("Units Sold")]
        public int UnitsSold { get; set; }

        [Name("Manufacturing Price")]
        public decimal ManufacturingPrice { get; set; }

        [Name("Sale Price")]
        public decimal SalePrice { get; set; }        

    }
}