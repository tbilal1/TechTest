﻿using DevTest.Apps.ProductSales.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevTest.Apps.ProductSales.Data.Interfaces
{
    public interface ISalesDataRepository
    {
        Task<List<SaleEntry>> GetAllSales();

        Task<List<SaleEntry>> GetCountrySales(string country);

        Task<List<SaleEntry>> GetSegmentSales(string segement);
        
    }
}
