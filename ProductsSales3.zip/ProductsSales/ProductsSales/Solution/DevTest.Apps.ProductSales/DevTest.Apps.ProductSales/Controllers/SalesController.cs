﻿using DevTest.Apps.ProductSales.Business.Interfaces;
using DevTest.Apps.ProductSales.Common.Models;
using DevTest.Apps.ProductSales.Data.Interfaces;
using DevTest.Apps.ProductSales.Models;
using DevTest.Apps.ProductSales.UI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DevTest.Apps.ProductSales.UI.Controllers
{
    public class SalesController : Controller
    {

        private readonly ISalesService _salesService;

        public SalesController(ISalesService salesService)
        {
            _salesService = salesService;
        }


        // GET: Get all Sales
        public async Task<IActionResult> Index()
        {
            try
            {
                var result = await _salesService.GetAllSales();                        

                return View(result);
            }
            catch (Exception ex)
            {
                //manage exceptions
                return View("~/Views/Shared/Error.cshtml", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
            
        }

        // POST: Get filtered sales
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GetSales(IFormCollection collection)
        {
	    
            try
            {
                //Extract Segemnt, country and Product values from the form collection
		// populate a criteria object

		// send it to the _salesService.GetSales(criteriaObj)

		// rerturn the filtered result to the viw
            }
            catch
            {
                return View();
            }
        }

        
    }
}
