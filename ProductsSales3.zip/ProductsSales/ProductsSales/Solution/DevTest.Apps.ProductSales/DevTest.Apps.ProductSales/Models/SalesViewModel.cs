﻿using DevTest.Apps.ProductSales.Common.Models;

namespace DevTest.Apps.ProductSales.UI.Models
{
    public class SalesViewModel
    {
        public List<SaleEntry> SaleEntries { get; set; }

        //other states, data or flags to control razor processing
        public string Message { get; set; }

    }
}
