Notes:
1. Three layer application architcture used >> UI Layer, Business Layer, Common Layer and Data access layer
2. Have tried to adhere to SOLID principles.
3. Services consume clients by interfaces e.g dependency between the SalesService and the CSV client is via an interface. 
Can be extended to use other clients
4. CSVHelper library is used to read the CSV file.
5. Did not have time to add on other prod level service i.e. configuration manager, Logging, exception handling, Unit Testing etc.
