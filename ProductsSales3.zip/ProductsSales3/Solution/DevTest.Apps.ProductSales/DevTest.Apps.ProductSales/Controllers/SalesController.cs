﻿using DevTest.Apps.ProductSales.Business.Interfaces;
using DevTest.Apps.ProductSales.Common.Models;
using DevTest.Apps.ProductSales.Data.Interfaces;
using DevTest.Apps.ProductSales.Models;
using DevTest.Apps.ProductSales.UI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DevTest.Apps.ProductSales.UI.Controllers
{
    public class SalesController : Controller
    {

        private readonly ISalesService _salesService;

        public SalesController(ISalesService salesService)
        {
            _salesService = salesService;
        }


        /// <summary>
        /// Get all Sales
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            try
            {
                var result = await _salesService.GetAllSales();                        

                return View(result);
            }
            catch (Exception ex)
            {
                //manage exceptions
                return View("~/Views/Shared/Error.cshtml", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
            
        }

        /// <summary>
        /// Get filtered sales
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GetSales(IFormCollection collection)
        {
	    
            try
            {
                //Extract Segemnt, country and Product values from the form collection

		        // populate a criteria object
                var filterCriteria = new SearchCriteria
                { Segment = "", Product = "", Country = null };

                var result = await _salesService.GetSales(filterCriteria);

                return View(result);
            }
            catch
            {
                return View();
            }
        }

        
    }
}
