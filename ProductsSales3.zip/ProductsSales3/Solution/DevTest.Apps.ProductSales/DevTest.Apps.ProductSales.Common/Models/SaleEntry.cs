﻿using CsvHelper.Configuration.Attributes;
using DevTest.Apps.ProductSales.Common.Enums;
using System.Collections.Generic;

namespace DevTest.Apps.ProductSales.Common.Models
{
    public class SaleEntry
    {
        [Name("Segment")]
        public required string Segment { get; set; }

        [Name("Country")]
        public required string Country { get; set; }

        //public required Product Product { get; set; }
        [Name("Product")]
        public required string Product { get; set; }

        [Name("Discount Band")]
        public string? DiscountBand { get; set; }

        [Name("Units Sold")]
        public int UnitsSold { get; set; }

        [Name("Manufacturing Price")]
        public decimal ManufacturingPrice { get; set; }

        [Name("Sale Price")]
        public decimal SalePrice { get; set; }        

        [Name("Date")]
        public DateTime SaleDate { get; set; }

        //this will not work > 1 to many >> rethink
        //public decimal TotalSalesBySegment { get; set; }
        //public decimal TotalSalesByCountry { get; set; }

    }
}