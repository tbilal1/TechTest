﻿using CsvHelper.Configuration.Attributes;
using System.Collections.Generic;

namespace DevTest.Apps.ProductSales.Common.Models
{
    public class SearchCriteria
    {
        public string? Segment { get; set; } = null;
        public string? Country { get; set; } = null;     
        public string? Product { get; set; } = null;

    }
}