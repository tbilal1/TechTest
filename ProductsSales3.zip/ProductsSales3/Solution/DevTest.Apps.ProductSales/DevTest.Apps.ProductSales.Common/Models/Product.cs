﻿using CsvHelper.Configuration.Attributes;
using System.Collections.Generic;

namespace DevTest.Apps.ProductSales.Common.Models
{
    public class Product
    {
        [Name("Product")]
        public required string Name { get; set; }

        [Name("Units Sold")]
        public int UnitsSold { get; set; }

        [Name("Manufacturing Price")]
        public decimal ManufacturingPrice { get; set; }

        [Name("Sale Price")]
        public decimal SalePrice { get; set; }        

    }
}