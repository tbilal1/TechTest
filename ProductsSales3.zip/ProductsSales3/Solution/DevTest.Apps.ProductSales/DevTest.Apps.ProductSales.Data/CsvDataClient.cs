﻿using CsvHelper;
using DevTest.Apps.ProductSales.Common.Models;
using DevTest.Apps.ProductSales.Data.Interfaces;
using System.Globalization;
using System;
using System.Collections.Generic;

namespace DevTest.Apps.ProductSales.Data
{
    public class CsvDataClient : ISalesDataRepository
    {
        //todo: setup and pick up from config
        string csvFile = @"C:\Source\Test\ProductsSales\Data\SalesData2.csv";
       
        public async Task<List<SaleEntry>> GetAllSales()
        {
            List<SaleEntry> saleRecords;

            using (var reader = new StreamReader(csvFile))

            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                saleRecords = csv.GetRecords<SaleEntry>().ToList();
            }

            return saleRecords;            
        }

	public async Task<List<SaleEntry>> GetSales(SearchCriteria criteria)
        {
	        //todo: test this
            var allSales = await GetAllSales();

	        //apply filtering on the returned sales list using linq extended methods based on the criteria passed in
	
	        var filteredSales = allSales.Where(x => !String.IsNullOrEmpty(x.Segment) && x.Segment == criteria.Segment)
			                            .Where(x => !String.IsNullOrEmpty(x.Country) && x.Country == criteria.Country)
			                            .Where(x => !String.IsNullOrEmpty(x.Product) && x.Product == criteria.Product).ToList();
	    
            return filteredSales;     
        }

        public Task<List<SaleEntry>> GetCountrySales(string country)
        {
            throw new NotImplementedException();
        }

        public Task<List<SaleEntry>> GetSegmentSales(string segement)
        {
            throw new NotImplementedException();
        }
    }
}
