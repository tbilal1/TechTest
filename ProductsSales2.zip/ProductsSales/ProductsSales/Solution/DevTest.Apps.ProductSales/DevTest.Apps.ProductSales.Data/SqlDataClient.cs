﻿using DevTest.Apps.ProductSales.Common.Models;
using DevTest.Apps.ProductSales.Data.Interfaces;

namespace DevTest.Apps.ProductSales.Data
{
    public class SqlDataClient : ISalesDataRepository
    {
        public Task<List<SaleEntry>> GetAllSales()
        {
            throw new NotImplementedException();
        }

        public Task<List<SaleEntry>> GetCountrySales(string country)
        {
            throw new NotImplementedException();
        }

        public Task<List<SaleEntry>> GetSegmentSales(string segement)
        {
            throw new NotImplementedException();
        }
    }
}
