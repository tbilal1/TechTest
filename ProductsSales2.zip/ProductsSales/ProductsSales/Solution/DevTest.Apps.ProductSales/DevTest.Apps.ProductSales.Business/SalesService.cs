﻿using DevTest.Apps.ProductSales.Business.Interfaces;
using DevTest.Apps.ProductSales.Common.Models;
using DevTest.Apps.ProductSales.Data.Interfaces;
using System.Xml.Linq;

namespace DevTest.Apps.ProductSales.Business
{
    public class SalesService : ISalesService
    {
        private readonly ISalesDataRepository _salesRepo;  

        public SalesService(ISalesDataRepository salesRepo)
        {
            _salesRepo = salesRepo; 
        }
        public async Task<List<SaleEntry>> GetAllSales()
        {
            var sales = await _salesRepo.GetAllSales();
            return sales;            
        }

        public Task<List<SaleEntry>> GetCountrySales(string country)
        {

            throw new NotImplementedException();
        }

        public Task<List<SaleEntry>> GetCountrySalesSummary()
        {
            throw new NotImplementedException();
        }

        public Task<List<SaleEntry>> GetSegmentSales(string segement)
        {
            throw new NotImplementedException();
        }

        public Task<List<SaleEntry>> GetSegmentSalesSummary()
        {
            throw new NotImplementedException();
        }
    }
}
