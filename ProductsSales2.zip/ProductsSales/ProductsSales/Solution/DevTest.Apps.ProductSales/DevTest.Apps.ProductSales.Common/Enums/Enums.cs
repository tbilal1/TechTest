﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevTest.Apps.ProductSales.Common.Enums
{
    //public int EmailTwoFaActivateTemplateId { get; set; }

    //[NextSetting("journey.email.2faDeactivate.templateId")]
    //public int EmailTwoFaDeactivateTemplateId { get; set; }

    //[NextSetting("journey.email.2faEnforce.templateId")]
    //public int EmailTwoFaEnforceTemplateId { get; set; }

    //[NextSetting("journey.email.2faPasscodeSend.templateId")]
    //public int EmailTwoFaPasscodeTemplateId { get; set; }

    //[NextSetting("journey.sms.2faPasscodeSend.templateId")]
    //public int SMSTwoFaPasscodeTemplateId { get; set; }
    public enum DiscountBand
    {
        None,
        Low,
        Medium,
        High
    }   

    
}
